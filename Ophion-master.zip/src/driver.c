/*
*   driver.c - windows kernel driver entry point for the hypervisor
*   creates a device object, symbolic link, and initializes vmx
*   provides ioctl interface for usermode loader communication
*/
#include <ntifs.h>
#include "hv.h"

#define DEVICE_NAME     L"\\Device\\Ophion"
#define SYMLINK_NAME    L"\\DosDevices\\Ophion"

#define IOCTL_BASE      0x800
#define IOCTL_HV_STATUS CTL_CODE(FILE_DEVICE_UNKNOWN, IOCTL_BASE + 0, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HV_EPT_HOOK CTL_CODE(FILE_DEVICE_UNKNOWN, IOCTL_BASE + 1, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct _EPT_HOOK_REQUEST {
    UINT32 ProcessId;
    PVOID  VirtualAddress;
    UCHAR  PatchBytes[16];
    UINT32 PatchSize;
} EPT_HOOK_REQUEST, *PEPT_HOOK_REQUEST;

typedef struct _EPT_HOOK_REQUEST32 {
    UINT32 ProcessId;
    UINT32 VirtualAddress;
    UCHAR  PatchBytes[16];
    UINT32 PatchSize;
} EPT_HOOK_REQUEST32, *PEPT_HOOK_REQUEST32;

static NTSTATUS DriverCreateClose(PDEVICE_OBJECT device_obj, PIRP irp);
static NTSTATUS DriverIoControl(PDEVICE_OBJECT device_obj, PIRP irp);
static NTSTATUS DriverHandleEptHook(_In_ PEPT_HOOK_REQUEST req);
static VOID DriverProcessNotifyEx(_Inout_ PEPROCESS process, _In_ HANDLE process_id, _Inout_opt_ PPS_CREATE_NOTIFY_INFO create_info);

static VOID
DriverProcessNotifyEx(
    _Inout_ PEPROCESS process,
    _In_ HANDLE process_id,
    _Inout_opt_ PPS_CREATE_NOTIFY_INFO create_info)
{
    UNREFERENCED_PARAMETER(process);

    if (create_info == NULL)
    {
        ept_unhook_process(process_id);
    }
}

VOID
DriverUnload(_In_ PDRIVER_OBJECT driver_obj)
{
    UNICODE_STRING symlink;

    DbgPrintEx(0, 0, "[hv] Unloading hypervisor driver...\n");

    PsSetCreateProcessNotifyRoutineEx(DriverProcessNotifyEx, TRUE);

    broadcast_terminate_all();
    vmx_terminate();

    RtlInitUnicodeString(&symlink, SYMLINK_NAME);
    IoDeleteSymbolicLink(&symlink);

    if (driver_obj->DeviceObject)
    {
        IoDeleteDevice(driver_obj->DeviceObject);
    }

    DbgPrintEx(0, 0, "[hv] Driver unloaded.\n");
}

NTSTATUS
DriverEntry(
    _In_ PDRIVER_OBJECT  driver_obj,
    _In_ PUNICODE_STRING registry_path)
{
    NTSTATUS       status;
    PDEVICE_OBJECT device_obj = NULL;
    UNICODE_STRING device_name;
    UNICODE_STRING symlink;

    UNREFERENCED_PARAMETER(registry_path);

    DbgPrintEx(0, 0, "[hv] DriverEntry — Hypervisor initializing...\n");

    RtlInitUnicodeString(&device_name, DEVICE_NAME);
    status = IoCreateDevice(
        driver_obj,
        0,
        &device_name,
        FILE_DEVICE_UNKNOWN,
        FILE_DEVICE_SECURE_OPEN,
        FALSE,
        &device_obj);

    if (!NT_SUCCESS(status))
    {
        DbgPrintEx(0, 0, "[hv] IoCreateDevice failed: 0x%X\n", status);
        return status;
    }

    RtlInitUnicodeString(&symlink, SYMLINK_NAME);
    status = IoCreateSymbolicLink(&symlink, &device_name);

    if (!NT_SUCCESS(status))
    {
        DbgPrintEx(0, 0, "[hv] IoCreateSymbolicLink failed: 0x%X\n", status);
        IoDeleteDevice(device_obj);
        return status;
    }

    driver_obj->DriverUnload                         = DriverUnload;
    driver_obj->MajorFunction[IRP_MJ_CREATE]         = DriverCreateClose;
    driver_obj->MajorFunction[IRP_MJ_CLOSE]          = DriverCreateClose;
    driver_obj->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DriverIoControl;

    if (!vmx_init())
    {
        DbgPrintEx(0, 0, "[hv] VMX initialization FAILED!\n");
        broadcast_terminate_all();
        vmx_terminate();
        IoDeleteSymbolicLink(&symlink);
        IoDeleteDevice(device_obj);
        return STATUS_HV_OPERATION_FAILED;
    }

    status = PsSetCreateProcessNotifyRoutineEx(DriverProcessNotifyEx, FALSE);
    if (!NT_SUCCESS(status))
    {
        DbgPrintEx(0, 0, "[hv] PsSetCreateProcessNotifyRoutineEx(register) failed: 0x%X\n", status);
        broadcast_terminate_all();
        vmx_terminate();
        IoDeleteSymbolicLink(&symlink);
        IoDeleteDevice(device_obj);
        return status;
    }

    DbgPrintEx(0, 0, "[hv] Hypervisor loaded and active on all cores!\n");
    return STATUS_SUCCESS;
}

static NTSTATUS
DriverCreateClose(
    _In_ PDEVICE_OBJECT device_obj,
    _In_ PIRP           irp)
{
    UNREFERENCED_PARAMETER(device_obj);

    irp->IoStatus.Status      = STATUS_SUCCESS;
    irp->IoStatus.Information = 0;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

static NTSTATUS
DriverHandleEptHook(
    _In_ PEPT_HOOK_REQUEST req)
{
    NTSTATUS    status;
    PEPROCESS   target_process = NULL;
    KAPC_STATE  apc_state;
    PVOID       page_base;
    SIZE_T      page_offset;
    UINT64      target_cr3 = 0;
    PMDL        locked_mdl = NULL;
    BOOLEAN     pages_locked = FALSE;
    PVOID       source_page = NULL;
    PPFN_NUMBER pfns = NULL;
    SIZE_T      phys_addr = 0;

    if (!req->VirtualAddress)
    {
        return STATUS_INVALID_ADDRESS;
    }

    if (req->PatchSize == 0 || req->PatchSize > sizeof(req->PatchBytes))
    {
        return STATUS_INVALID_BUFFER_SIZE;
    }

    page_offset = BYTE_OFFSET(req->VirtualAddress);
    if ((PAGE_SIZE - page_offset) < req->PatchSize)
    {
        DbgPrintEx(0, 0, "[hv] IOCTL_HV_EPT_HOOK rejected cross-page patch (offset=0x%Ix size=0x%X)\n",
                 page_offset, req->PatchSize);
        return STATUS_NOT_SUPPORTED;
    }

    status = PsLookupProcessByProcessId((HANDLE)(ULONG_PTR)req->ProcessId, &target_process);
    if (!NT_SUCCESS(status))
    {
        return status;
    }

    page_base = PAGE_ALIGN(req->VirtualAddress);

    KeStackAttachProcess(target_process, &apc_state);
    target_cr3 = __readcr3() & ~0xFFFULL;

    locked_mdl = IoAllocateMdl(page_base, PAGE_SIZE, FALSE, FALSE, NULL);
    if (!locked_mdl)
    {
        status = STATUS_INSUFFICIENT_RESOURCES;
        goto Exit;
    }

    __try
    {
        MmProbeAndLockPages(locked_mdl, UserMode, IoReadAccess);
        pages_locked = TRUE;
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        status = GetExceptionCode();
        DbgPrintEx(0, 0, "[hv] MmProbeAndLockPages failed for %p: 0x%X\n",
                 req->VirtualAddress, status);
        goto Exit;
    }

    source_page = MmGetSystemAddressForMdlSafe(
        locked_mdl,
        HighPagePriority | MdlMappingNoExecute);
    if (!source_page)
    {
        status = STATUS_INSUFFICIENT_RESOURCES;
        goto Exit;
    }

    pfns = MmGetMdlPfnArray(locked_mdl);
    if (!pfns)
    {
        status = STATUS_UNSUCCESSFUL;
        goto Exit;
    }

    phys_addr = ((SIZE_T)pfns[0] * PAGE_SIZE) + page_offset;

    if (!ept_hook_page(
            phys_addr,
            source_page,
            page_base,
            target_cr3,
            page_offset,
            req->PatchBytes,
            req->PatchSize,
            locked_mdl,
            PsGetProcessId(target_process)))
    {
        status = STATUS_UNSUCCESSFUL;
        goto Exit;
    }

    locked_mdl = NULL;
    pages_locked = FALSE;
    status = STATUS_SUCCESS;

Exit:
    KeUnstackDetachProcess(&apc_state);

    if (pages_locked)
    {
        MmUnlockPages(locked_mdl);
    }

    if (locked_mdl)
    {
        IoFreeMdl(locked_mdl);
    }

    ObDereferenceObject(target_process);
    return status;
}

static NTSTATUS
DriverIoControl(
    _In_ PDEVICE_OBJECT device_obj,
    _In_ PIRP           irp)
{
    NTSTATUS           status = STATUS_SUCCESS;
    PIO_STACK_LOCATION io_stack;
    ULONG              ioctl_code;

    UNREFERENCED_PARAMETER(device_obj);

    io_stack       = IoGetCurrentIrpStackLocation(irp);
    ioctl_code = io_stack->Parameters.DeviceIoControl.IoControlCode;
    irp->IoStatus.Information = 0;

    switch (ioctl_code)
    {
    case IOCTL_HV_STATUS:
    {
        //
        // return basic status: number of virtualized cores
        //
        if (io_stack->Parameters.DeviceIoControl.OutputBufferLength >= sizeof(UINT32))
        {
            *(UINT32 *)irp->AssociatedIrp.SystemBuffer = g_cpu_count;
            irp->IoStatus.Information = sizeof(UINT32);
        }
        else
        {
            status = STATUS_BUFFER_TOO_SMALL;
        }
        break;
    }

    case IOCTL_HV_EPT_HOOK:
    {
        ULONG input_len = io_stack->Parameters.DeviceIoControl.InputBufferLength;

        if (input_len >= sizeof(EPT_HOOK_REQUEST))
        {
            PEPT_HOOK_REQUEST req = (PEPT_HOOK_REQUEST)irp->AssociatedIrp.SystemBuffer;
            status = DriverHandleEptHook(req);
        }
        else if (input_len >= sizeof(EPT_HOOK_REQUEST32))
        {
            PEPT_HOOK_REQUEST32 req32 = (PEPT_HOOK_REQUEST32)irp->AssociatedIrp.SystemBuffer;
            EPT_HOOK_REQUEST req = { 0 };

            req.ProcessId      = req32->ProcessId;
            req.VirtualAddress = (PVOID)(ULONG_PTR)req32->VirtualAddress;
            RtlCopyMemory(req.PatchBytes, req32->PatchBytes, sizeof(req.PatchBytes));
            req.PatchSize      = req32->PatchSize;

            DbgPrintEx(0, 0, "[hv] IOCTL_HV_EPT_HOOK: accepted 32-bit request (pid=%u, va=%p, inlen=%lu)\n",
                     req.ProcessId, req.VirtualAddress, input_len);

            status = DriverHandleEptHook(&req);
        }
        else
        {
            DbgPrintEx(0, 0, "[hv] IOCTL_HV_EPT_HOOK: input buffer too small (got=%lu, need=%Iu or %Iu)\n",
                     input_len, sizeof(EPT_HOOK_REQUEST), sizeof(EPT_HOOK_REQUEST32));
            status = STATUS_BUFFER_TOO_SMALL;
        }
        break;
    }

    default:
        //
        // add more shi here later
        //
        status = STATUS_INVALID_DEVICE_REQUEST;
        break;
    }

    irp->IoStatus.Status = status;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return status;
}
